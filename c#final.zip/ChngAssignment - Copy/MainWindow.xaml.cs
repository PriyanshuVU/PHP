﻿using System;
using System.Diagnostics;
using System.Threading.Tasks;
using System.Windows;
using PasswordBruteForce.Models;

namespace PasswordBruteForce
{
    public partial class MainWindow : Window
    {
        private string _encryptedPassword;
        private BruteForce _bruteForce;

        public MainWindow()
        {
            InitializeComponent();
            _bruteForce = new BruteForce();
        }

        private void CreatePasswordButton_Click(object sender, RoutedEventArgs e)
        {
            string password = PasswordTextBox.Text;
            if (string.IsNullOrEmpty(password))
            {
                MessageBox.Show("Please enter a password.");
                return;
            }
            _encryptedPassword = PasswordEncryptor.EncryptPassword(password);
            MessageBox.Show("Password encrypted successfully.");
        }

        private async void BruteForceButton_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrEmpty(_encryptedPassword))
            {
                MessageBox.Show("Please create a password first.");
                return;
            }

            Stopwatch stopwatch = Stopwatch.StartNew();
            string decryptedPassword = await _bruteForce.DecryptPasswordAsync(_encryptedPassword);
            stopwatch.Stop();

            DecryptedPasswordTextBox.Text = decryptedPassword;
            ResultTextBlock.Text = $"Time Taken: {stopwatch.Elapsed.TotalSeconds:F2} seconds";
        }
    }
}
